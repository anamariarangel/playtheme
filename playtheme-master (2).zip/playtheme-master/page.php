<?php get_header(); ?>

<main>
    <section class="section-header">
        <div class="article-box">
            <?php 
            /* Start the Loop */
            $args = array('post_type' => 'videos', 'posts_per_page' => 1);
            $new_query_videos = new WP_Query($args);
            
            if ($new_query_videos->have_posts()) : 
                while ($new_query_videos->have_posts()) : 
                    $new_query_videos->the_post(); 
            ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>          
                        <img class="article-box__dynamic-cover" 
                             src="<?php echo esc_url(get_post_meta(get_the_ID(), 'playtheme_video_cover', true)); ?>" />
                        
                        <div class="article-box__video-data">
                            <div class="box__btn">
                            <button class="btn btn--white">
                               <?php 
                                $terms = get_the_terms(get_the_ID(), 'videos_category');
                                if ($terms && !is_wp_error($terms)) {
                                    $term_names = wp_list_pluck($terms, 'name');
                                    echo esc_html(implode(', ', $term_names));
                                } else {
                                    echo esc_html('Sem categoria');
                                }
                                ?>
                            </button>

                            <button class="btn btn--black">
                                <?php echo esc_html(get_post_meta(get_the_ID(), 'playtheme_video_length', true)); ?> 
                            </button>
                            </div>
                            
                            <div class="article-box__title-area">
                                <a href="<?php the_permalink(); ?>"> 
                                    <h1 class="heading-primary"><?php the_title(); ?></h1>
                                </a>
                                <a href="<?php the_permalink(); ?>">
                                    <button class="btn btn--red-desktop">Mais Informações</button>
                                </a>
                                <a href="<?php the_permalink(); ?>">
                                    <button class="btn btn--red-phone">Assistir</button>
                                </a>
                            </div>
                        </div>
                    </article>
            <?php 
                endwhile; 
                wp_reset_postdata(); 
            else : 
            ?>
                <p>Nenhum vídeo encontrado.</p>
            <?php endif; ?>
        </div>  
    </section>
    
    <section class="section-slider">
        <!-- SLIDER FILMES -->
        <?php get_template_part('parts/film-carousel'); ?>

        <!-- SLIDER SERIES --> 
        <?php get_template_part('parts/series-carousel'); ?>

        <!-- SLIDER DOCUMENTARIOS -->
        <?php get_template_part('parts/docs-carousel'); ?>

    </section>
</main>

<?php get_footer(); ?>
