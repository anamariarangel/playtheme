<div class="article-slider">
    <div class="article-slider__inner">  
        <article class="article">
            <div class="article-slider__thumb">
                <?php if (has_post_thumbnail()) : ?>
                    <img class="article-slider__img" src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" />
                <?php endif; ?>
            </div>

            <div class="article-slider__data">  
                <button class="btn btn--black btn--article">
                    <?php echo esc_html(get_post_meta($post->ID, 'playtheme_video_length', true)); ?>
                </button>
                <div class="article-slider__wrap-title">
                    <a href="<?php the_permalink(); ?>">
                        <h3 class="heading-tertiary">
                            <?php the_title(); ?>
                        </h3>
                    </a>
                </div>
            </div>                  
        </article>
    </div>
</div>
