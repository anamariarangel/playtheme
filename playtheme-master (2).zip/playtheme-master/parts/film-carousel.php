<div>
            <a href="/index.php?cat=1">
                <h2 class="heading-secondary">Filmes</h2>
            </a>   
        </div>
        <div class="slider-single">
            <i class="btn-arrow btn-arrow--left left-docs fas fa-chevron-left"></i>
            <i class="btn-arrow btn-arrow--right right-docs fas fa-chevron-right"></i>   

            <div class="slider-single__wrapper"> 
                <div class="slider-single__article-docs">            
                    <?php 
                    // LOOP FILMES
                    $argument2 = array(
                        'post_type' => 'videos', 
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'videos_category', 
                                'field'    => 'slug', 
                                'terms'    => 'filmes', 
                            ),
                        ),
                    );

                    $filmes = new WP_Query($argument2);
                    if ($filmes->have_posts()) : 
                        while ($filmes->have_posts()) : 
                            $filmes->the_post();
                    ?>
                        <div class="article-slider item-docs current-item-docs">
                            <div class="article-slider__inner">  
                                <article class="article">
                                    <div class="article-slider__thumb">
                                        <img class="article-slider__img your-custom-class" src="<?php echo esc_url(get_the_post_thumbnail_url($post->ID)); ?>" alt="<?php echo esc_attr(get_the_title($post->ID)); ?>" />
                                    </div>
                                    <div class="article-slider__data">  
                                        <button class="btn btn--black btn--article">
                                            <?php echo esc_html(get_post_meta($post->ID, 'playtheme_video_length', true)); ?>
                                        </button>

                                        <a href="<?php the_permalink(); ?>">
                                            <h3 class="heading-tertiary"> 
                                                <?php the_title(); ?>
                                            </h3>
                                        </a>
                                    </div>                  
                                </article>
                            </div>
                        </div>
                    <?php 
                        endwhile; 
                    endif; 
                    wp_reset_postdata(); 
                    ?>          
                </div>
            </div>
        </div>
