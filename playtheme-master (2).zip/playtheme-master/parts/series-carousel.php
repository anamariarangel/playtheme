<div>
            <a href="/index.php?cat=3">
                <h2 class="heading-secondary">Séries</h2>
            </a>   
        </div>
        <div class="slider-single">
            <i class="btn-arrow btn-arrow--left left-series fas fa-chevron-left"></i>
            <i class="btn-arrow btn-arrow--right right-series fas fa-chevron-right"></i>   

            <div class="slider-single__wrapper"> 
                <div class="slider-single__article-series">            
                    <?php 
                    // LOOP series
                    $argument2 = array(
                        'post_type' => 'videos', 
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'videos_category', 
                                'field'    => 'slug', 
                                'terms'    => 'series', 
                            ),
                        ),
                    );

                    $series = new WP_Query($argument2);
                    if ($series->have_posts()) : 
                        while ($series->have_posts()) : 
                            $series->the_post();
                    ?>
                        <div class="article-slider item-series current-item-series">
                            <div class="article-slider__inner">  
                                <article class="article">
                                    <div class="article-slider__thumb">
                                        <img class="article-slider__img your-custom-class" src="<?php echo esc_url(get_the_post_thumbnail_url($post->ID)); ?>" alt="<?php echo esc_attr(get_the_title($post->ID)); ?>" />
                                    </div>
                                    <div class="article-slider__data">  
                                        <button class="btn btn--black btn--article">
                                            <?php echo esc_html(get_post_meta($post->ID, 'playtheme_video_length', true)); ?>
                                        </button>

                                        <a href="<?php the_permalink(); ?>">
                                            <h3 class="heading-tertiary"> 
                                                <?php the_title(); ?>
                                            </h3>
                                        </a>
                                    </div>                  
                                </article>
                            </div>
                        </div>
                    <?php 
                        endwhile; 
                    endif; 
                    wp_reset_postdata(); 
                    ?>          
                </div>
            </div>
        </div>