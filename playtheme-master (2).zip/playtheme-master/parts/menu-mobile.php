<div>
  <nav class="mobile-menu">
    <ul class="mobile-menu__active">
        <li class="mobile-menu__item"> 
           <a href="<?php echo esc_url(get_term_link('filmes', 'videos_category')); ?>">
                <i class="fas fa-video mobile-menu__icon iconfilme"></i>
                <p class="mobile-menu__p menufilme">Filmes</p>
           </a>
        </li>
                
        <li class="mobile-menu__item">
           <a href="<?php echo esc_url(get_term_link('documentarios', 'videos_category')); ?>">
                <i class="fas fa-film mobile-menu__icon icondocumentario"></i>
                <p class="mobile-menu__p menudocumentario">Documentários</p>
           </a>
        </li>

        <li class="mobile-menu__item">
           <a href="<?php echo esc_url(get_term_link('series', 'videos_category')); ?>">
                <i class="fa-regular fa-circle-play mobile-menu__icon iconserie"></i>
                <p class="mobile-menu__p menuserie">Séries</p>
           </a>
        </li>
    </ul>
  </nav>
</div>
