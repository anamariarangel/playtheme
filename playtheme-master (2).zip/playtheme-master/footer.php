<?php get_template_part('parts/menu-mobile'); ?>

<?php wp_footer(); ?>

<footer>
    <div class="footer">
       <a href="<?php echo esc_url(home_url()); ?>">
            <img class="footer__logo-img" 
            src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/play-light@2x.png'); ?>"  alt="Logo">
       </a>                  
        <p>Copyright <?php echo date('Y'); ?> - All Rights Reserved</p>  
    </div>
</footer>
</body>
</html>
