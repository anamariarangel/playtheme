<?php
// Remove default image sizes
function playtheme_remove_default_image_sizes() {
    remove_image_size('thumbnail'); 
    remove_image_size('medium');     
    remove_image_size('medium_large'); 
    remove_image_size('large');      
    remove_image_size('1536x1536'); 
    remove_image_size('2048x2048'); 
}
add_action('init', 'playtheme_remove_default_image_sizes');

// Function to get attachment ID by file name
function get_attachment_id_by_filename($filename) {
    global $wpdb;
    $filename = sanitize_file_name($filename);
    $attachment = $wpdb->get_var($wpdb->prepare(
        "SELECT ID FROM $wpdb->posts WHERE post_type = 'attachment' AND post_title = %s",
        pathinfo($filename, PATHINFO_FILENAME)
    ));

    return $attachment ? $attachment : null;
}

// Load images and avoid creating other sizes
function playtheme_load_images() {
    $upload_dir = wp_upload_dir(); 
    $image_dir = get_template_directory() . '/assets/images/post-images'; 
    $images = array_merge(
        array_map(function ($n) { return "cover{$n}.webp"; }, range(1, 18)),
        array_map(function ($n) { return "thumbnail{$n}.webp"; }, range(1, 18))
    );

    foreach ($images as $image) {
        $image_path = $image_dir . '/' . $image;
        if (file_exists($image_path)) {
            $new_image_path = $upload_dir['path'] . '/' . basename($image_path);
            $existing_image_id = get_attachment_id_by_filename($image);

            if (!$existing_image_id) {
                if (copy($image_path, $new_image_path)) {
                    $wp_filetype = wp_check_filetype(basename($new_image_path), null);
                    $attachment = array(
                        'guid'           => $upload_dir['url'] . '/' . basename($new_image_path),
                        'post_mime_type' => $wp_filetype['type'],
                        'post_title'     => sanitize_file_name(pathinfo($image, PATHINFO_FILENAME)),
                        'post_content'   => '',
                        'post_status'    => 'inherit'
                    );
                    // Insert the attachment into the media library and get the ID
                    $attach_id = wp_insert_attachment($attachment, $new_image_path);
                    if ($attach_id) {
                        
                        require_once(ABSPATH . 'wp-admin/includes/image.php');
                        $attach_data = wp_generate_attachment_metadata($attach_id, $new_image_path);
                        wp_update_attachment_metadata($attach_id, $attach_data);

                        error_log("Anexo criado com sucesso: ID " . $attach_id);
                    } else {
                        error_log("Falha ao criar o anexo para: " . $new_image_path);
                    }
                } else {
                    error_log("Falha ao copiar a imagem: $image_path para $new_image_path");
                }
            } else {
                error_log("A imagem já existe: " . basename($image_path) . " com ID " . $existing_image_id);
            }
        } else {
            error_log("Arquivo não encontrado: $image_path");
        }
    }
}
add_action('after_switch_theme', 'playtheme_load_images');

// Function to check if posts have already been created
function playtheme_check_if_posts_exist() {
    $args = array(
        'post_type'   => 'videos',
        'post_status' => 'any',
        'posts_per_page' => 1,
    );
    $posts = get_posts($args);

    return !empty($posts); 
}
// Function to create custom 'videos' posts
function playtheme_create_video_posts() {
    if (playtheme_check_if_posts_exist()) {
        error_log("Os posts já existem, não serão criados novamente.");
        return;
    }

    // Generate arrays of image file names
    $cover_images = array_map(function ($n) { return "cover{$n}.webp"; }, range(1, 18));
    $thumbnail_images = array_map(function ($n) { return "thumbnail{$n}.webp"; }, range(1, 18));

    // Gets the image IDs
    $cover_image_ids = array_map('get_attachment_id_by_filename', $cover_images);
    $thumbnail_image_ids = array_map('get_attachment_id_by_filename', $thumbnail_images);

    if (empty($cover_image_ids) || empty($thumbnail_image_ids)) {
        error_log("Erro: IDs de imagens de capa ou thumbnail não foram encontrados.");
        return;
    }

    $used_cover_images = [];
    $used_thumbnail_images = [];

    // Categories
    $terms = array('Filmes', 'Séries', 'Documentários');
    $category_ids = [];
    $category_counts = array_fill_keys($terms, 0); // Category counter 

    // Insert categories and get their IDs
    foreach ($terms as $term) {
        $term_data = term_exists($term, 'videos_category');
        if ($term_data) {
            $category_ids[$term] = $term_data['term_id'];
        } else {
            $inserted_term = wp_insert_term($term, 'videos_category');
            if (!is_wp_error($inserted_term)) {
                $category_ids[$term] = $inserted_term['term_id'];
            }
        }
    }

    // List of words to create unique titles
    $words = explode(' ', 'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua');

    // Creating posts
    for ($i = 1; $i <= 18; $i++) {
        // Generate a title of four unique words
        $random_keys = array_rand($words, 4);
        $post_title = implode(' ', array_intersect_key($words, array_flip($random_keys)));

        $video_length = rand(50, 240) . ' min'; 
        $video_sinopse = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.';
        $video_description = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';
        $video_embed = 'https://www.youtube.com/watch?v=QUkmkNqAfaY';

        // Choose an unused cover image
        do {
            $cover_image_id = $cover_image_ids[array_rand($cover_image_ids)];
        } while (in_array($cover_image_id, $used_cover_images));

        $used_cover_images[] = $cover_image_id; // Marcar como usada

        // Choose an unused thumbnail
        do {
            $thumbnail_image_id = $thumbnail_image_ids[array_rand($thumbnail_image_ids)];
        } while (in_array($thumbnail_image_id, $used_thumbnail_images));

        $used_thumbnail_images[] = $thumbnail_image_id; 

        $cover_image_url = wp_get_attachment_url($cover_image_id);

        // Post Data
        $post_data = array(
            'post_title'   => $post_title,
            'post_content' => '',
            'post_status'  => 'publish',
            'post_type'    => 'videos',
        );

        $post_id = wp_insert_post($post_data);

        if ($post_id && !is_wp_error($post_id)) {
            error_log("Post criado com sucesso: ID " . $post_id);

            // Assign category if there are not already 6 posts in that category
            foreach ($terms as $term) {
                if ($category_counts[$term] < 6) {
                    wp_set_post_terms($post_id, array($category_ids[$term]), 'videos_category');
                    $category_counts[$term]++; 
                    break;
                }
            }

            // update metadata
            update_post_meta($post_id, 'playtheme_video_length', $video_length);
            update_post_meta($post_id, 'playtheme_video_sinopse', $video_sinopse);
            update_post_meta($post_id, 'playtheme_video_embed', $video_embed);
            update_post_meta($post_id, 'playtheme_video_description', $video_description);
            update_post_meta($post_id, 'playtheme_video_cover', $cover_image_url);

            // defining thumbnail
            if ($thumbnail_image_id) {
                set_post_thumbnail($post_id, $thumbnail_image_id);
                error_log("Imagem destacada definida para o post ID " . $post_id);
            } else {
                error_log("Falha ao definir a imagem destacada para o post ID " . $post_id);
            }
        } else {
            error_log("Erro ao criar o post $i: " . ($post_id ? $post_id->get_error_message() : 'Erro desconhecido'));
        }
    }
}

add_action('after_switch_theme', function() {
    playtheme_load_images();
    playtheme_create_video_posts();
});
