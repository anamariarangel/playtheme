<?php

// Function to register the Custom Post Type "Videos" and the taxonomy "videos_category"
function custom_post_video() {
    // Labels 
    $labels = array(
        'singular_name'         => _x('Video', 'Video', 'play_theme'),
        'name'                  => _x('Videos', 'Video', 'play_theme'),
        'menu_name'             => __('Videos', 'play_theme'),
        'name_admin_bar'        => __('Video', 'play_theme'),
        'archives'              => __('Item Archives', 'play_theme'),
        'attributes'            => __('Video Attributes', 'play_theme'),
        'parent_item_colon'     => __('Parent Item:', 'play_theme'),
        'all_items'             => __('All Videos', 'play_theme'),
        'add_new_item'          => __('Add New Item', 'play_theme'),
        'add_new'               => __('Add New', 'play_theme'),
        'new_item'              => __('New Video', 'play_theme'),
        'edit_item'             => __('Edit Video', 'play_theme'),
        'update_item'           => __('Update Video', 'play_theme'),
        'view_item'             => __('View Video', 'play_theme'),
        'view_items'            => __('View Videos', 'play_theme'),
        'search_items'          => __('Search Video', 'play_theme'),
        'not_found'             => __('Not found', 'play_theme'),
        'not_found_in_trash'    => __('Not found in Trash', 'play_theme'),
        'featured_image'        => __('Featured Image', 'play_theme'),
        'set_featured_image'    => __('Set featured image', 'play_theme'),
        'remove_featured_image' => __('Remove featured image', 'play_theme'),
        'use_featured_image'    => __('Use as featured image', 'play_theme'),
        'insert_into_item'      => __('Insert into item', 'play_theme'),
        'uploaded_to_this_item' => __('Uploaded to this video', 'play_theme'),
        'items_list'            => __('Videos list', 'play_theme'),
        'items_list_navigation' => __('Videos list navigation', 'play_theme'),
        'filter_items_list'     => __('Filter items list', 'play_theme'),
    );

    // Arguments for the Custom Post Type "Videos"
    $args = array(
        'label'                 => __('videos', 'play_theme'),
        'description'           => __('videos', 'play_theme'),
        'labels'                => $labels,
        'supports'              => array('title', 'thumbnail'),
        'taxonomies'            => array('videos_category'), 
        'hierarchical'          => true,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 1,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'page',
        'menu_icon'             => 'dashicons-format-video',
        'rewrite'               => array('slug' => 'videos'), 
    );

    register_post_type('videos', $args);

   // Labels for the "videos_category" taxonomy
    $taxonomy_labels = array(
        'name'                       => __('Categorias', 'play_theme'),
        'singular_name'              => __('Categoria', 'play_theme'),
        'menu_name'                  => __('Categorias', 'play_theme'),
        'all_items'                  => __('Todas as Categorias', 'play_theme'),
        'parent_item'                => __('Categoria Pai', 'play_theme'),
        'parent_item_colon'          => __('Categoria Pai:', 'play_theme'),
        'new_item_name'              => __('Novo Nome da Categoria', 'play_theme'),
        'add_new_item'               => __('Adicionar Nova Categoria', 'play_theme'),
        'edit_item'                  => __('Editar Categoria', 'play_theme'),
        'update_item'                => __('Atualizar Categoria', 'play_theme'),
        'view_item'                  => __('Ver Categoria', 'play_theme'),
        'separate_items_with_commas' => __('Separar categorias com vírgulas', 'play_theme'),
        'add_or_remove_items'        => __('Adicionar ou remover categorias', 'play_theme'),
        'choose_from_most_used'      => __('Escolher entre as mais usadas', 'play_theme'),
        'popular_items'              => __('Categorias populares', 'play_theme'),
        'search_items'               => __('Buscar Categorias', 'play_theme'),
        'not_found'                  => __('Nenhuma categoria encontrada', 'play_theme'),
        'no_terms'                   => __('Sem categorias', 'play_theme'),
        'items_list'                 => __('Lista de categorias', 'play_theme'),
        'items_list_navigation'      => __('Navegação na lista de categorias', 'play_theme'),
    );

    // Arguments for the "videos_category" taxonomy
    $taxonomy_args = array(
        'labels'                     => $taxonomy_labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'rewrite'                    => array(
             'slug' => 'videos_category',  
            'with_front' => false,              
        ),
    );

    register_taxonomy('videos_category', 'videos', $taxonomy_args);

// Add specific terms (categories) 
$terms = array(
    'Filmes' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris ut imperdiet libero. Phasellus eu purus posuere, sodales nisi ut, varius neque. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nunc eu tempor sapien, vitae maximus lorem. Pellentesque hendrerit nunc rutrum nunc molestie, euismod interdum est suscipit. Suspendisse imperdiet iaculis tempor. Mauris rutrum blandit nisl, at pulvinar velit ullamcorper quis. Nam pharetra turpis aliquet egestas maximus. Proin venenatis, elit id laoreet porta, elit magna pellentesque arcu, nec congue orci felis finibus diam. Donec leo tortor, ultrices quis urna non, sollicitudin feugiat neque. Nulla nibh neque, feugiat eu gravida id, egestas facilisis mauris. Phasellus dui tellus, semper eget leo sit amet, dictum molestie purus. Fusce quis urna odio.',
    'Séries' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris ut imperdiet libero. Phasellus eu purus posuere, sodales nisi ut, varius neque. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nunc eu tempor sapien, vitae maximus lorem. Pellentesque hendrerit nunc rutrum nunc molestie, euismod interdum est suscipit. Suspendisse imperdiet iaculis tempor. Mauris rutrum blandit nisl, at pulvinar velit ullamcorper quis. Nam pharetra turpis aliquet egestas maximus. Proin venenatis, elit id laoreet porta, elit magna pellentesque arcu, nec congue orci felis finibus diam. Donec leo tortor, ultrices quis urna non, sollicitudin feugiat neque. Nulla nibh neque, feugiat eu gravida id, egestas facilisis mauris. Phasellus dui tellus, semper eget leo sit amet, dictum molestie purus. Fusce quis urna odio.',
    'Documentários' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris ut imperdiet libero. Phasellus eu purus posuere, sodales nisi ut, varius neque. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nunc eu tempor sapien, vitae maximus lorem. Pellentesque hendrerit nunc rutrum nunc molestie, euismod interdum est suscipit. Suspendisse imperdiet iaculis tempor. Mauris rutrum blandit nisl, at pulvinar velit ullamcorper quis. Nam pharetra turpis aliquet egestas maximus. Proin venenatis, elit id laoreet porta, elit magna pellentesque arcu, nec congue orci felis finibus diam. Donec leo tortor, ultrices quis urna non, sollicitudin feugiat neque. Nulla nibh neque, feugiat eu gravida id, egestas facilisis mauris. Phasellus dui tellus, semper eget leo sit amet, dictum molestie purus. Fusce quis urna odio.',
);

foreach ($terms as $term => $description) {
    wp_insert_term(
        $term, 
        'videos_category', 
        array(
            'description' => $description, 
            'slug' => sanitize_title($term), 
        )
    );
}

}

add_action('init', 'custom_post_video', 0);

// add customfields 

function playtheme_add_custom_box() {
    $screens = ['post', 'videos'];
    add_meta_box(
        'playtheme_box_',                 // Unique ID
        'Cadastro de Vídeos',             // Box title
        'playtheme_custom_box_html',      // Content callback
        $screens                          // Post type
    );
}
add_action('add_meta_boxes', 'playtheme_add_custom_box');

function playtheme_custom_box_html($post) {
    // Retrieve field values
    $vlenght = get_post_meta($post->ID, 'playtheme_video_lenght', true);
    $vsinopse = get_post_meta($post->ID, 'playtheme_video_sinopse', true);
    $vembed = get_post_meta($post->ID, 'playtheme_video_embed', true);
    $vdescription = get_post_meta($post->ID, 'playtheme_video_description', true);
    $vcover = get_post_meta($post->ID, 'playtheme_video_cover', true); 

    ?>
    <div class="custom-fields">
        <input type="hidden" name="playtheme_nonce" value="<?php echo wp_create_nonce('playtheme_nonce'); ?>"/>
                
        <label for="playtheme_video_embed">Código Embed</label>
        <input class="small_input" type="text" name="playtheme_video_embed" id="playtheme_video_embed" 
               value="<?php echo esc_attr($vembed); ?>">

        <label for="playtheme_video_lenght">Duração do Vídeo</label>
        <input class="small_input" type="text" name="playtheme_video_lenght" id="playtheme_video_lenght" 
               value="<?php echo esc_attr($vlenght); ?>">

        <label for="playtheme_video_description">Descrição</label>
        <textarea class="input_all" name="playtheme_video_description" id="playtheme_video_description"><?php echo esc_textarea($vdescription); ?></textarea>

        <label for="playtheme_video_sinopse">Sinopse</label>
        <textarea class="input_all" name="playtheme_video_sinopse" id="playtheme_video_sinopse"><?php echo esc_textarea($vsinopse); ?></textarea>

        <label for="playtheme_video_cover">Carregar Imagem de Capa</label>
        <p> Clique no botão para fazer o upload de um documento. 
            Após o término do upload, clique em <em>Inserir no post</em>.</p>
        <input id="playtheme_upload_file" type="text" size="150" name="playtheme_video_cover" style="max-width: 600px;" class="input-video"
               value="<?php echo esc_url($vcover); ?>" >
        <input id="upload_file_button" type="button" class="button-upload" value="Fazer upload" style="max-width:300px; margin-bottom:20px; margin-top:15px;">

        <!-- display cover image -->
        <?php if (!empty($vcover)) : ?>
            <div class="playtheme-video-cover-preview">
                <label>Imagem de Capa Atual:</label><br>
                <img src="<?php echo esc_url($vcover); ?>" style="max-width:300px; height: auto;">
            </div>
        <?php endif; ?>
    </div>

    <style>
        .playtheme-video-cover-preview img {
            margin-top: 10px;
            display: block;
            max-width: 100%;
            height: auto;
        }
    </style>

    <?php
}

// Replicate Wordpress Uploader
add_action('admin_head', 'playtheme_meta_uploader_script');
function playtheme_meta_uploader_script() { ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#upload_file_button').click(function() {
                var formfield = $('#playtheme_upload_file');
                tb_show('', 'media-upload.php?TB_iframe=true');

                window.send_to_editor = function(html) {
                    var fileurl = $(html).attr('href');
                    formfield.val(fileurl);
                    $('.playtheme-video-cover-preview img').attr('src', fileurl); 
                    tb_remove();
                }

                return false;
            });
        });
    </script>
<?php }

// Save post custom fields
function playtheme_save_postdata($post_id) {
    if (isset($_POST['playtheme_nonce']) && !wp_verify_nonce($_POST['playtheme_nonce'], 'playtheme_nonce')) {
        return $post_id;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return $post_id;
    }

    
    $fields = array(
        'playtheme_video_embed',
        'playtheme_video_lenght',
        'playtheme_video_sinopse',
        'playtheme_video_description',
        'playtheme_video_cover', 
    );

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
        }
    }
}
add_action('save_post', 'playtheme_save_postdata');


