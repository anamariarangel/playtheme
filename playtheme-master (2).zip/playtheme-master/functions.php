<?php

require('custom-post/cpt-videos.php');
require('custom-post/create-upload-images.php');

// Enqueue scripts and styles
function playtheme_load_scripts() {
    wp_enqueue_style('playtheme_style', get_stylesheet_uri(), array(), '1.0', 'all');
    wp_enqueue_script('font_awesome', get_template_directory_uri() . '/assets/js/font-awesome/fontawesome.min.js', array(), '1.0', true);
    wp_enqueue_script('font_awesome_regular', get_template_directory_uri() . '/assets/js/font-awesome/regular.min.js', array(), '1.0', true);
    wp_enqueue_script('font_awesome_solid', get_template_directory_uri() . '/assets/js/font-awesome/solid.min.js', array(), '1.0', true);
    wp_enqueue_script('menu-mobile', get_template_directory_uri() . '/assets/js/menu-mobile.js', array(), '1.0', true);
    wp_enqueue_script('playtheme_player', get_template_directory_uri() . '/assets/js/player.js', array(), '1.0', true);
    wp_enqueue_script('playtheme_filme-slider', get_template_directory_uri() . '/assets/js/slider.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'playtheme_load_scripts');

// Enqueue scripts and admin styles
function playtheme_admin_styles() {
    wp_enqueue_style('stylesheet', get_template_directory_uri() . '/admin.css');
}
add_action('admin_head', 'playtheme_admin_styles');

// Theme Settings
function playtheme_config() {
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'width' => 104,
        'height' => 33,
        'flex-height' => true,
        'flex-width' => true,
    ));
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array('comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
}
add_action('after_setup_theme', 'playtheme_config', 0);


if (!function_exists('wp_body_open')) {
    function wp_body_open() {
        do_action('wp_body_open');
    }
}

// Creating Home Page
function create_custom_home_page() {
    // Verifica se a página "Home" já existe
    $home_page = get_page_by_title('Home');

    if (!$home_page) {
        // Cria a página "Home"
        $home_page_id = wp_insert_post(array(
            'post_title'   => 'Home',
            'post_content' => '', // Conteúdo da página
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ));

        if (!is_wp_error($home_page_id)) {
            // Define a página "Home" como a página inicial
            update_option('show_on_front', 'page');
            update_option('page_on_front', $home_page_id);
        }
    } else {
        // Se a página já existir, apenas define como a página inicial
        update_option('show_on_front', 'page');
        update_option('page_on_front', $home_page->ID);
    }
}
add_action('after_switch_theme', 'create_custom_home_page');


// Function to display categories from the custom post type 'videos'
function playtheme_add_video_categories_to_menu() {
    $args = array(
        'taxonomy'   => 'videos_category', 
        'hide_empty' => false, 
    );

    $categories = get_categories($args);

    if ($categories) {
        echo '<ul class="video-categories-menu">';
        foreach ($categories as $category) {
            echo '<li><a href="' . esc_url(get_term_link($category)) . '">' . esc_html($category->name) . '</a></li>';
        }
        echo '</ul>';
    }
}

// Display the menu in the desired location
function playtheme_display_main_menu() {
   // Add video categories to the menu
    playtheme_add_video_categories_to_menu();
}

// Remove home page from menu
add_filter('wp_nav_menu_objects', 'remove_home_from_menu');

function remove_home_from_menu($items) {
    foreach ($items as $key => $item) {
            if ($item->title == 'Home') {
            unset($items[$key]);
        }
    }
    return $items;
}


// Function to force the use of the taxonomy-videos_category.php template
function force_videos_category_template($template) {
    if (is_tax('videos_category')) {
        $custom_template = locate_template('taxonomy-videos_category.php');
        if ($custom_template) {
            return $custom_template;
        }
    }

    return $template;
}

add_filter('template_include', 'force_videos_category_template');


// Defines the permalink structure
function set_default_permalink_structure() {
    
    $permalink_structure = '/%post_type%/%taxonomy%/%category%/%post_name%/';
    update_option('permalink_structure', $permalink_structure);
    flush_rewrite_rules();
}

add_action('after_switch_theme', 'set_default_permalink_structure');
