<?php get_header(); ?>

<main>
  <!-- Arquivo -->
  <section class="section-archive">
    <div class="category-archive">
      <div class="category-archive__aside">
        <h1 class="heading-secondary filme"><?php esc_html(single_cat_title()); ?></h1>
        <p class="paragraph"><?php echo the_archive_description(); ?></p>
      </div>

      <div class="category-archive__thumb">                      
        <div class="category-archive__article">
          <?php 
         
          if ( have_posts() ) :
            while ( have_posts() ) : the_post();
            
              get_template_part( 'parts/content');
            endwhile;
              the_posts_pagination();

          else :
              echo '<p>No videos found.</p>';
          endif;
          ?>          
        </div>
      </div>
    </div>          
  </section> 

  <?php get_template_part('parts/menu-mobile'); ?>

</main>   

<?php get_footer(); ?>
