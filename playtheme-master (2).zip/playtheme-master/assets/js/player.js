document.addEventListener('DOMContentLoaded', function() {
    // 1. Captures the embed content value
    function getEmbedContentValue() {
        // Selects the first element with the class 'embed-content'
        var embedElement = document.querySelector('.embed-content');
        
        // Checks if the element exists
        if (embedElement) {
            // Stores the content value of the element in the variable
            var embedContentValue = embedElement.textContent || embedElement.innerText;
            return embedContentValue.trim(); // removes extra white spaces
        } else {
            // Returns null if the element is not found
            return null;
        }
    }
  
    // Example of usage
    var videoId = getEmbedContentValue();
  
    // 2. This code loads the IFrame Player API asynchronously.
    var tag = document.createElement('script');
    tag.src = "https://www.youtube.com/iframe_api";
    var firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
  
    // 3. This function creates an <iframe> (and YouTube player)
    //    after the API code downloads.
    var player;
    window.onYouTubeIframeAPIReady = function() {
        if (videoId) {
            player = new YT.Player('player', {
                width: '960',
                height: '540',
                videoId: videoId, // Uses the captured value as videoId
                events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });
        } else {
            console.error("No videoId found.");
        }
    };
  
    // 4. The API calls this function when the video player is ready.
    function onPlayerReady(event) {
        event.target.playVideo();
    }
  
    // 5. The API calls this function when the player's state changes.
    var done = false;
    function onPlayerStateChange(event) {
        if (event.data == YT.PlayerState.PLAYING && !done) {
            setTimeout(stopVideo, 6000);
            done = true;
        }
    }
    function stopVideo() {
        player.stopVideo();
    }
  });
  