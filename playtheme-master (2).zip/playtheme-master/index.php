<?php
//Silence is golden. 
?>